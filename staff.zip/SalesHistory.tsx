import { useState, useEffect } from "react";
import { useNavigate } from "react-router";
import { ArrowLeft, Search, Filter, Calendar, DollarSign, CreditCard, Banknote, Receipt, Eye } from "lucide-react";
import { motion } from "motion/react";
import { getTodaySales, getSales, Sale, getSalesStats } from "../../../utils/sales";

export function SalesHistory() {
  const navigate = useNavigate();
  const [sales, setSales] = useState<Sale[]>([]);
  const [filteredSales, setFilteredSales] = useState<Sale[]>([]);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState<"all" | "completed" | "pending" | "cancelled">("all");
  const [filterPeriod, setFilterPeriod] = useState<"today" | "all">("today");
  const [selectedSale, setSelectedSale] = useState<Sale | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);

  useEffect(() => {
    loadSales();
  }, [filterPeriod]);

  useEffect(() => {
    applyFilters();
  }, [sales, searchTerm, filterStatus]);

  const loadSales = () => {
    const allSales = filterPeriod === "today" ? getTodaySales() : getSales();
    setSales(allSales.sort((a, b) =>
      new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
    ));
  };

  const applyFilters = () => {
    let filtered = [...sales];

    if (filterStatus !== "all") {
      filtered = filtered.filter(s => s.status === filterStatus);
    }

    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filtered = filtered.filter(s =>
        s.saleNumber.toLowerCase().includes(term) ||
        s.customerName.toLowerCase().includes(term) ||
        s.vehiclePlate?.toLowerCase().includes(term) ||
        s.customerPhone?.toLowerCase().includes(term)
      );
    }

    setFilteredSales(filtered);
  };

  const stats = getSalesStats(sales);

  const getPaymentIcon = (method: string) => {
    switch (method) {
      case "cash":
        return Banknote;
      case "card":
        return CreditCard;
      case "transfer":
        return DollarSign;
      default:
        return Receipt;
    }
  };

  const getPaymentLabel = (method: string) => {
    switch (method) {
      case "cash":
        return "Efectivo";
      case "card":
        return "Tarjeta";
      case "transfer":
        return "Transferencia";
      case "mixed":
        return "Mixto";
      default:
        return method;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-100 text-green-700";
      case "pending":
        return "bg-yellow-100 text-yellow-700";
      case "cancelled":
        return "bg-red-100 text-red-700";
      default:
        return "bg-gray-100 text-gray-700";
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case "completed":
        return "Completada";
      case "pending":
        return "Pendiente";
      case "cancelled":
        return "Cancelada";
      default:
        return status;
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
    });
  };

  const viewSaleDetail = (sale: Sale) => {
    setSelectedSale(sale);
    setShowDetailModal(true);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <button
            onClick={() => navigate(-1)}
            className="flex items-center gap-2 mb-4 text-blue-100 hover:text-white transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
            <span>Volver</span>
          </button>
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold mb-2">Historial de Ventas</h1>
              <p className="text-blue-100">Consulta y gestiona las ventas realizadas</p>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-6 py-8">
        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="bg-white rounded-xl shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Total Ventas</p>
              <Receipt className="h-5 w-5 text-blue-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stats.totalSales}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.05 }}
            className="bg-white rounded-xl shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Monto Total</p>
              <DollarSign className="h-5 w-5 text-green-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">${stats.totalAmount.toFixed(2)}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="bg-white rounded-xl shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Ticket Promedio</p>
              <Receipt className="h-5 w-5 text-purple-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">${stats.averageTicket.toFixed(2)}</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15 }}
            className="bg-white rounded-xl shadow-sm p-6"
          >
            <div className="flex items-center justify-between mb-2">
              <p className="text-sm text-gray-600">Efectivo/Tarjeta</p>
              <CreditCard className="h-5 w-5 text-orange-600" />
            </div>
            <p className="text-2xl font-bold text-gray-900">{stats.cashPayments}/{stats.cardPayments}</p>
          </motion.div>
        </div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="bg-white rounded-xl shadow-sm p-6 mb-6"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Buscar por número, cliente, placa..."
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            {/* Status Filter */}
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
              >
                <option value="all">Todos los estados</option>
                <option value="completed">Completadas</option>
                <option value="pending">Pendientes</option>
                <option value="cancelled">Canceladas</option>
              </select>
            </div>

            {/* Period Filter */}
            <div className="relative">
              <Calendar className="absolute left-3 top-1/2 -translate-y-1/2 h-5 w-5 text-gray-400" />
              <select
                value={filterPeriod}
                onChange={(e) => setFilterPeriod(e.target.value as any)}
                className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent appearance-none"
              >
                <option value="today">Hoy</option>
                <option value="all">Todas</option>
              </select>
            </div>
          </div>
        </motion.div>

        {/* Sales Table */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.25 }}
          className="bg-white rounded-xl shadow-sm overflow-hidden"
        >
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Número</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Cliente</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Placa</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Total</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Pago</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Estado</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Fecha</th>
                  <th className="px-6 py-4 text-left text-xs font-semibold text-gray-700 uppercase">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {filteredSales.length === 0 ? (
                  <tr>
                    <td colSpan={8} className="px-6 py-12 text-center text-gray-500">
                      No se encontraron ventas
                    </td>
                  </tr>
                ) : (
                  filteredSales.map((sale) => {
                    const PaymentIcon = getPaymentIcon(sale.paymentMethod);
                    return (
                      <tr key={sale.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-6 py-4">
                          <span className="font-semibold text-gray-900">{sale.saleNumber}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div>
                            <p className="font-medium text-gray-900">{sale.customerName}</p>
                            {sale.customerPhone && (
                              <p className="text-sm text-gray-500">{sale.customerPhone}</p>
                            )}
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-gray-900">{sale.vehiclePlate || "-"}</span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="font-semibold text-gray-900">${sale.total.toFixed(2)}</span>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-2">
                            <PaymentIcon className="h-4 w-4 text-gray-400" />
                            <span className="text-sm text-gray-700">{getPaymentLabel(sale.paymentMethod)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(sale.status)}`}>
                            {getStatusLabel(sale.status)}
                          </span>
                        </td>
                        <td className="px-6 py-4">
                          <span className="text-sm text-gray-600">{formatDate(sale.createdAt)}</span>
                        </td>
                        <td className="px-6 py-4">
                          <button
                            onClick={() => viewSaleDetail(sale)}
                            className="text-blue-600 hover:text-blue-700 font-medium text-sm flex items-center gap-1"
                          >
                            <Eye className="h-4 w-4" />
                            Ver
                          </button>
                        </td>
                      </tr>
                    );
                  })
                )}
              </tbody>
            </table>
          </div>
        </motion.div>
      </div>

      {/* Sale Detail Modal */}
      {showDetailModal && selectedSale && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="bg-white rounded-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto"
          >
            <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4">
              <div className="flex items-center justify-between">
                <h3 className="text-xl font-bold">Detalle de Venta</h3>
                <button
                  onClick={() => setShowDetailModal(false)}
                  className="text-gray-400 hover:text-gray-600"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="p-6 space-y-6">
              {/* Sale Info */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-gray-500 mb-1">Número de Venta</p>
                  <p className="font-semibold text-gray-900">{selectedSale.saleNumber}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Estado</p>
                  <span className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusColor(selectedSale.status)}`}>
                    {getStatusLabel(selectedSale.status)}
                  </span>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Cliente</p>
                  <p className="font-medium text-gray-900">{selectedSale.customerName}</p>
                  {selectedSale.customerEmail && <p className="text-sm text-gray-600">{selectedSale.customerEmail}</p>}
                  {selectedSale.customerPhone && <p className="text-sm text-gray-600">{selectedSale.customerPhone}</p>}
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Vehículo</p>
                  <p className="font-medium text-gray-900">{selectedSale.vehiclePlate || "-"}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Cajero</p>
                  <p className="font-medium text-gray-900">{selectedSale.cashierName}</p>
                </div>
                <div>
                  <p className="text-sm text-gray-500 mb-1">Fecha</p>
                  <p className="font-medium text-gray-900">{formatDate(selectedSale.createdAt)}</p>
                </div>
              </div>

              {/* Items */}
              <div>
                <h4 className="font-semibold mb-3">Artículos</h4>
                <div className="border border-gray-200 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-semibold text-gray-700">Artículo</th>
                        <th className="px-4 py-2 text-right text-xs font-semibold text-gray-700">Cant.</th>
                        <th className="px-4 py-2 text-right text-xs font-semibold text-gray-700">Precio</th>
                        <th className="px-4 py-2 text-right text-xs font-semibold text-gray-700">Subtotal</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-gray-200">
                      {selectedSale.items.map((item, idx) => (
                        <tr key={idx}>
                          <td className="px-4 py-3">
                            <div>
                              <p className="font-medium text-gray-900">{item.itemName}</p>
                              <p className="text-xs text-gray-500 capitalize">{item.type}</p>
                            </div>
                          </td>
                          <td className="px-4 py-3 text-right text-gray-700">{item.quantity}</td>
                          <td className="px-4 py-3 text-right text-gray-700">${item.unitPrice.toFixed(2)}</td>
                          <td className="px-4 py-3 text-right font-medium text-gray-900">${item.subtotal.toFixed(2)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Totals */}
              <div className="border-t border-gray-200 pt-4 space-y-2">
                <div className="flex justify-between text-gray-700">
                  <span>Subtotal:</span>
                  <span>${selectedSale.subtotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between text-gray-700">
                  <span>IVA (8%):</span>
                  <span>${selectedSale.tax.toFixed(2)}</span>
                </div>
                {selectedSale.discount > 0 && (
                  <div className="flex justify-between text-green-600">
                    <span>Descuento:</span>
                    <span>-${selectedSale.discount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between text-xl font-bold text-gray-900 pt-2 border-t border-gray-200">
                  <span>Total:</span>
                  <span>${selectedSale.total.toFixed(2)}</span>
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <p className="text-sm text-gray-500 mb-1">Método de Pago</p>
                <div className="flex items-center gap-2">
                  {(() => {
                    const PaymentIcon = getPaymentIcon(selectedSale.paymentMethod);
                    return <PaymentIcon className="h-5 w-5 text-gray-400" />;
                  })()}
                  <span className="font-medium text-gray-900">{getPaymentLabel(selectedSale.paymentMethod)}</span>
                </div>
              </div>

              {/* Notes */}
              {selectedSale.notes && (
                <div>
                  <p className="text-sm text-gray-500 mb-1">Notas</p>
                  <p className="text-gray-700">{selectedSale.notes}</p>
                </div>
              )}
            </div>

            <div className="sticky bottom-0 bg-gray-50 px-6 py-4 border-t border-gray-200">
              <button
                onClick={() => setShowDetailModal(false)}
                className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
              >
                Cerrar
              </button>
            </div>
          </motion.div>
        </div>
      )}
    </div>
  );
}
