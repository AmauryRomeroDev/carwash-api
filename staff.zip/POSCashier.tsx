import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router';
import {
  ShoppingCart,
  Plus,
  Minus,
  Trash2,
  DollarSign,
  CreditCard,
  Smartphone,
  Receipt,
  X,
  Search,
  Package,
  Sparkles,
  History,
} from 'lucide-react';
import { getServices, Service } from '../../../utils/services';
import { getProducts, Product } from '../../../utils/products';
import { addSale, SaleItem } from '../../../utils/sales';

export function POSCashier() {
  const navigate = useNavigate();
  const [services, setServices] = useState<Service[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<SaleItem[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [activeTab, setActiveTab] = useState<'services' | 'products'>('services');
  const [showCheckout, setShowCheckout] = useState(false);
  const [customerData, setCustomerData] = useState({
    name: '',
    email: '',
    phone: '',
    vehiclePlate: '',
  });
  const [paymentMethod, setPaymentMethod] = useState<'cash' | 'card' | 'transfer'>('cash');
  const [discount, setDiscount] = useState(0);

  useEffect(() => {
    const isAuth = localStorage.getItem('isAuthenticated');
    if (!isAuth) {
      navigate('/');
      return;
    }

    setServices(getServices().filter(s => s.isActive));
    setProducts(getProducts().filter(p => p.isActive));
  }, [navigate]);

  const addToCart = (item: Service | Product, type: 'service' | 'product') => {
    const existingItem = cart.find(
      i => i.itemId === item.id && i.type === type
    );

    if (existingItem) {
      setCart(
        cart.map(i =>
          i.itemId === item.id && i.type === type
            ? {
                ...i,
                quantity: i.quantity + 1,
                subtotal: (i.quantity + 1) * i.unitPrice,
              }
            : i
        )
      );
    } else {
      const newItem: SaleItem = {
        type,
        itemId: item.id,
        itemName: item.name,
        quantity: 1,
        unitPrice: item.price,
        subtotal: item.price,
      };
      setCart([...cart, newItem]);
    }
  };

  const updateQuantity = (itemId: string, type: 'service' | 'product', delta: number) => {
    setCart(
      cart
        .map(item => {
          if (item.itemId === itemId && item.type === type) {
            const newQuantity = item.quantity + delta;
            if (newQuantity <= 0) return null;
            return {
              ...item,
              quantity: newQuantity,
              subtotal: newQuantity * item.unitPrice,
            };
          }
          return item;
        })
        .filter(Boolean) as SaleItem[]
    );
  };

  const removeFromCart = (itemId: string, type: 'service' | 'product') => {
    setCart(cart.filter(item => !(item.itemId === itemId && item.type === type)));
  };

  const calculateTotals = () => {
    const subtotal = cart.reduce((sum, item) => sum + item.subtotal, 0);
    const tax = subtotal * 0.08; // 8% tax
    const total = subtotal + tax - discount;
    return { subtotal, tax, total };
  };

  const handleCheckout = () => {
    if (cart.length === 0) {
      alert('El carrito está vacío');
      return;
    }
    if (!customerData.name) {
      alert('Por favor ingresa el nombre del cliente');
      return;
    }
    setShowCheckout(true);
  };

  const completeSale = () => {
    const { subtotal, tax, total } = calculateTotals();
    const cashierName = localStorage.getItem('userName') || 'Cajero';
    const cashierEmail = localStorage.getItem('userEmail') || 'cajero@autosplash.com';

    const sale = addSale({
      customerName: customerData.name,
      customerEmail: customerData.email || undefined,
      customerPhone: customerData.phone || undefined,
      vehiclePlate: customerData.vehiclePlate || undefined,
      items: cart,
      subtotal,
      tax,
      discount,
      total,
      paymentMethod,
      status: 'completed',
      cashierId: cashierEmail,
      cashierName,
      completedAt: new Date().toISOString(),
    });

    alert(`¡Venta completada! Número: ${sale.saleNumber}\nTotal: $${total.toFixed(2)}`);

    // Reset
    setCart([]);
    setCustomerData({ name: '', email: '', phone: '', vehiclePlate: '' });
    setDiscount(0);
    setShowCheckout(false);
  };

  const filteredServices = services.filter(s =>
    s.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const { subtotal, tax, total } = calculateTotals();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div
        className="text-white px-6 py-4 sticky top-0 z-40"
        style={{
          backgroundColor: 'var(--color-primary)',
          boxShadow: 'var(--shadow-md)',
        }}
      >
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold">Punto de Venta</h1>
            <p className="text-sm opacity-90">Registra ventas de servicios y productos</p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigate('/staff/sales')}
              className="px-4 py-2 rounded-lg transition-colors flex items-center gap-2"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
            >
              <History className="h-4 w-4" />
              <span>Historial</span>
            </button>
            <button
              onClick={() => navigate('/admin')}
              className="px-4 py-2 rounded-lg transition-colors"
              style={{ backgroundColor: 'rgba(255, 255, 255, 0.1)' }}
            >
              Volver al Admin
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <div className="grid lg:grid-cols-3 gap-6">
          {/* Products/Services Selection */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-xl p-6" style={{ boxShadow: 'var(--shadow-md)' }}>
              {/* Search */}
              <div className="mb-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={e => setSearchTerm(e.target.value)}
                    placeholder="Buscar servicios o productos..."
                    className="w-full pl-10 pr-4 py-3 rounded-lg"
                    style={{
                      border: '1px solid var(--color-border)',
                      outline: 'none',
                    }}
                  />
                </div>
              </div>

              {/* Tabs */}
              <div className="flex gap-2 mb-6">
                <button
                  onClick={() => setActiveTab('services')}
                  className="flex-1 py-3 px-4 rounded-lg font-medium transition-all"
                  style={{
                    backgroundColor:
                      activeTab === 'services'
                        ? 'var(--color-primary)'
                        : 'var(--color-surface)',
                    color: activeTab === 'services' ? 'white' : 'var(--color-text-secondary)',
                  }}
                >
                  <Sparkles className="w-5 h-5 inline mr-2" />
                  Servicios
                </button>
                <button
                  onClick={() => setActiveTab('products')}
                  className="flex-1 py-3 px-4 rounded-lg font-medium transition-all"
                  style={{
                    backgroundColor:
                      activeTab === 'products'
                        ? 'var(--color-primary)'
                        : 'var(--color-surface)',
                    color: activeTab === 'products' ? 'white' : 'var(--color-text-secondary)',
                  }}
                >
                  <Package className="w-5 h-5 inline mr-2" />
                  Productos
                </button>
              </div>

              {/* Items Grid */}
              <div className="grid grid-cols-2 md:grid-cols-3 gap-4 max-h-[60vh] overflow-y-auto">
                {activeTab === 'services' &&
                  filteredServices.map(service => (
                    <button
                      key={service.id}
                      onClick={() => addToCart(service, 'service')}
                      className="p-4 rounded-lg text-left transition-all hover:scale-105"
                      style={{
                        backgroundColor: 'var(--color-surface)',
                        border: '1px solid var(--color-border)',
                      }}
                    >
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center mb-3"
                        style={{
                          background:
                            'linear-gradient(135deg, var(--color-primary) 0%, var(--color-primary-dark) 100%)',
                        }}
                      >
                        <Sparkles className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                        {service.name}
                      </h3>
                      <p className="text-sm mb-2" style={{ color: 'var(--color-text-secondary)' }}>
                        {service.duration} min
                      </p>
                      <p className="text-lg font-bold" style={{ color: 'var(--color-primary)' }}>
                        ${service.price.toFixed(2)}
                      </p>
                    </button>
                  ))}

                {activeTab === 'products' &&
                  filteredProducts.map(product => (
                    <button
                      key={product.id}
                      onClick={() => addToCart(product, 'product')}
                      className="p-4 rounded-lg text-left transition-all hover:scale-105"
                      style={{
                        backgroundColor: 'var(--color-surface)',
                        border: '1px solid var(--color-border)',
                      }}
                    >
                      <div
                        className="w-12 h-12 rounded-lg flex items-center justify-center mb-3"
                        style={{
                          background:
                            'linear-gradient(135deg, var(--color-secondary) 0%, #0284c7 100%)',
                        }}
                      >
                        <Package className="w-6 h-6 text-white" />
                      </div>
                      <h3 className="font-semibold mb-1" style={{ color: 'var(--color-text)' }}>
                        {product.name}
                      </h3>
                      <p className="text-sm mb-2" style={{ color: 'var(--color-text-secondary)' }}>
                        Stock: {product.stock}
                      </p>
                      <p className="text-lg font-bold" style={{ color: 'var(--color-secondary)' }}>
                        ${product.price.toFixed(2)}
                      </p>
                    </button>
                  ))}
              </div>
            </div>
          </div>

          {/* Cart */}
          <div className="lg:col-span-1">
            <div
              className="bg-white rounded-xl p-6 sticky top-24"
              style={{ boxShadow: 'var(--shadow-md)' }}
            >
              <div className="flex items-center gap-2 mb-6">
                <ShoppingCart className="w-6 h-6" style={{ color: 'var(--color-primary)' }} />
                <h2 className="text-xl font-bold" style={{ color: 'var(--color-text)' }}>
                  Carrito ({cart.length})
                </h2>
              </div>

              {/* Cart Items */}
              <div className="space-y-3 mb-6 max-h-[40vh] overflow-y-auto">
                {cart.length === 0 ? (
                  <p className="text-center py-8" style={{ color: 'var(--color-text-secondary)' }}>
                    Carrito vacío
                  </p>
                ) : (
                  cart.map(item => (
                    <div
                      key={`${item.type}-${item.itemId}`}
                      className="p-3 rounded-lg"
                      style={{ backgroundColor: 'var(--color-surface)' }}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1">
                          <p className="font-medium text-sm" style={{ color: 'var(--color-text)' }}>
                            {item.itemName}
                          </p>
                          <p className="text-xs" style={{ color: 'var(--color-text-secondary)' }}>
                            ${item.unitPrice.toFixed(2)} c/u
                          </p>
                        </div>
                        <button
                          onClick={() => removeFromCart(item.itemId, item.type)}
                          className="p-1 rounded transition-colors"
                          style={{ color: 'var(--color-error)' }}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => updateQuantity(item.itemId, item.type, -1)}
                            className="w-7 h-7 rounded flex items-center justify-center"
                            style={{
                              backgroundColor: 'rgba(37, 99, 235, 0.1)',
                              color: 'var(--color-primary)',
                            }}
                          >
                            <Minus className="w-4 h-4" />
                          </button>
                          <span className="w-8 text-center font-medium">{item.quantity}</span>
                          <button
                            onClick={() => updateQuantity(item.itemId, item.type, 1)}
                            className="w-7 h-7 rounded flex items-center justify-center"
                            style={{
                              backgroundColor: 'rgba(37, 99, 235, 0.1)',
                              color: 'var(--color-primary)',
                            }}
                          >
                            <Plus className="w-4 h-4" />
                          </button>
                        </div>
                        <p className="font-bold" style={{ color: 'var(--color-text)' }}>
                          ${item.subtotal.toFixed(2)}
                        </p>
                      </div>
                    </div>
                  ))
                )}
              </div>

              {/* Totals */}
              {cart.length > 0 && (
                <>
                  <div className="space-y-2 mb-4 py-4" style={{ borderTop: '1px solid var(--color-border)' }}>
                    <div className="flex justify-between text-sm">
                      <span style={{ color: 'var(--color-text-secondary)' }}>Subtotal:</span>
                      <span style={{ color: 'var(--color-text)' }}>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span style={{ color: 'var(--color-text-secondary)' }}>Impuesto (8%):</span>
                      <span style={{ color: 'var(--color-text)' }}>${tax.toFixed(2)}</span>
                    </div>
                    {discount > 0 && (
                      <div className="flex justify-between text-sm">
                        <span style={{ color: 'var(--color-text-secondary)' }}>Descuento:</span>
                        <span style={{ color: 'var(--color-error)' }}>-${discount.toFixed(2)}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-lg font-bold pt-2" style={{ borderTop: '1px solid var(--color-border)' }}>
                      <span style={{ color: 'var(--color-text)' }}>Total:</span>
                      <span style={{ color: 'var(--color-primary)' }}>${total.toFixed(2)}</span>
                    </div>
                  </div>

                  <button
                    onClick={handleCheckout}
                    className="w-full py-3 rounded-lg font-semibold text-white transition-all hover:scale-105"
                    style={{
                      backgroundColor: 'var(--color-primary)',
                      boxShadow: 'var(--shadow-md)',
                    }}
                  >
                    Proceder al Pago
                  </button>
                </>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Checkout Modal */}
      {showCheckout && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
          <div
            className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto p-6"
            style={{ boxShadow: 'var(--shadow-lg)' }}
          >
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-2xl font-bold" style={{ color: 'var(--color-text)' }}>
                Finalizar Venta
              </h2>
              <button
                onClick={() => setShowCheckout(false)}
                className="p-2 rounded-lg transition-colors"
                style={{ backgroundColor: 'var(--color-surface)' }}
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="space-y-6">
              {/* Customer Info */}
              <div>
                <h3 className="font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
                  Datos del Cliente
                </h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="col-span-2">
                    <label className="block text-sm font-medium mb-2">
                      Nombre *
                    </label>
                    <input
                      type="text"
                      value={customerData.name}
                      onChange={e => setCustomerData({ ...customerData, name: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg"
                      style={{ border: '1px solid var(--color-border)' }}
                      required
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Email
                    </label>
                    <input
                      type="email"
                      value={customerData.email}
                      onChange={e => setCustomerData({ ...customerData, email: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg"
                      style={{ border: '1px solid var(--color-border)' }}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Teléfono
                    </label>
                    <input
                      type="tel"
                      value={customerData.phone}
                      onChange={e => setCustomerData({ ...customerData, phone: e.target.value })}
                      className="w-full px-4 py-3 rounded-lg"
                      style={{ border: '1px solid var(--color-border)' }}
                    />
                  </div>
                  <div className="col-span-2">
                    <label className="block text-sm font-medium mb-2">
                      Placa del Vehículo
                    </label>
                    <input
                      type="text"
                      value={customerData.vehiclePlate}
                      onChange={e =>
                        setCustomerData({ ...customerData, vehiclePlate: e.target.value.toUpperCase() })
                      }
                      className="w-full px-4 py-3 rounded-lg font-mono"
                      style={{ border: '1px solid var(--color-border)' }}
                      placeholder="ABC-123"
                    />
                  </div>
                </div>
              </div>

              {/* Payment Method */}
              <div>
                <h3 className="font-semibold mb-4" style={{ color: 'var(--color-text)' }}>
                  Método de Pago
                </h3>
                <div className="grid grid-cols-3 gap-3">
                  <button
                    onClick={() => setPaymentMethod('cash')}
                    className="p-4 rounded-lg transition-all"
                    style={{
                      backgroundColor:
                        paymentMethod === 'cash'
                          ? 'rgba(37, 99, 235, 0.1)'
                          : 'var(--color-surface)',
                      border: `2px solid ${
                        paymentMethod === 'cash' ? 'var(--color-primary)' : 'var(--color-border)'
                      }`,
                    }}
                  >
                    <DollarSign className="w-8 h-8 mx-auto mb-2" />
                    <p className="text-sm font-medium">Efectivo</p>
                  </button>
                  <button
                    onClick={() => setPaymentMethod('card')}
                    className="p-4 rounded-lg transition-all"
                    style={{
                      backgroundColor:
                        paymentMethod === 'card'
                          ? 'rgba(37, 99, 235, 0.1)'
                          : 'var(--color-surface)',
                      border: `2px solid ${
                        paymentMethod === 'card' ? 'var(--color-primary)' : 'var(--color-border)'
                      }`,
                    }}
                  >
                    <CreditCard className="w-8 h-8 mx-auto mb-2" />
                    <p className="text-sm font-medium">Tarjeta</p>
                  </button>
                  <button
                    onClick={() => setPaymentMethod('transfer')}
                    className="p-4 rounded-lg transition-all"
                    style={{
                      backgroundColor:
                        paymentMethod === 'transfer'
                          ? 'rgba(37, 99, 235, 0.1)'
                          : 'var(--color-surface)',
                      border: `2px solid ${
                        paymentMethod === 'transfer' ? 'var(--color-primary)' : 'var(--color-border)'
                      }`,
                    }}
                  >
                    <Smartphone className="w-8 h-8 mx-auto mb-2" />
                    <p className="text-sm font-medium">Transferencia</p>
                  </button>
                </div>
              </div>

              {/* Discount */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Descuento ($)
                </label>
                <input
                  type="number"
                  value={discount}
                  onChange={e => setDiscount(parseFloat(e.target.value) || 0)}
                  className="w-full px-4 py-3 rounded-lg"
                  style={{ border: '1px solid var(--color-border)' }}
                  min="0"
                  step="0.01"
                />
              </div>

              {/* Summary */}
              <div
                className="p-4 rounded-lg"
                style={{ backgroundColor: 'var(--color-surface)' }}
              >
                <h3 className="font-semibold mb-3">Resumen de Pago</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span>Subtotal:</span>
                    <span>${subtotal.toFixed(2)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span>Impuesto (8%):</span>
                    <span>${tax.toFixed(2)}</span>
                  </div>
                  {discount > 0 && (
                    <div className="flex justify-between" style={{ color: 'var(--color-error)' }}>
                      <span>Descuento:</span>
                      <span>-${discount.toFixed(2)}</span>
                    </div>
                  )}
                  <div
                    className="flex justify-between text-lg font-bold pt-2"
                    style={{ borderTop: '1px solid var(--color-border)' }}
                  >
                    <span>Total a Pagar:</span>
                    <span style={{ color: 'var(--color-primary)' }}>
                      ${total.toFixed(2)}
                    </span>
                  </div>
                </div>
              </div>

              <button
                onClick={completeSale}
                disabled={!customerData.name}
                className="w-full py-4 rounded-lg font-semibold text-white transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                style={{
                  backgroundColor: 'var(--color-success)',
                  boxShadow: 'var(--shadow-md)',
                }}
              >
                <Receipt className="w-5 h-5" />
                Completar Venta
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
